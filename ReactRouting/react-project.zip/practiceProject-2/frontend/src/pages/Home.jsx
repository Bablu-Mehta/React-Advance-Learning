import PageContent from "../components/PageContent";

function HomePage() {
  return (
    <PageContent title="WelCome!">
      <p>Browse all our Amazing Events!</p>
    </PageContent>
  );
}

export default HomePage;
